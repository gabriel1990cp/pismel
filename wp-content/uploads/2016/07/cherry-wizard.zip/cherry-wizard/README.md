# Cherry Installation Wizard
Сompatibility: Cherry Framework v.4+
